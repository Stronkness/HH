#include "swlinked.c"
struct c_list * createNode();
void put(struct c_list **prRefList, struct c_list *prObj);
void deleteNode(struct c_list ** list);